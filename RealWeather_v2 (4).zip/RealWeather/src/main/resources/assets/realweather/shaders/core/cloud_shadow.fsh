#version 150

uniform mat4 InvViewProj;
uniform sampler2D DepthSampler;
uniform vec3 CamPos;
uniform vec3 SunDir;
uniform vec2 WindOffset;
uniform float StormCount;
uniform float ShadowStrength;
uniform float AmbientCloud;
uniform float FlashAmt;
uniform vec3 FlashPos;

in vec2 ndc;
out vec4 fragColor;

float ss(float a, float b, float x) { return clamp((x - a) / (b - a), 0.0, 1.0); }

float hash13(vec3 p3) {
    p3 = fract(p3 * 0.1031);
    p3 += dot(p3, p3.zyx + 31.32);
    return fract((p3.x + p3.y) * p3.z);
}

float vnoise(vec3 x) {
    vec3 i = floor(x);
    vec3 f = fract(x);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(mix(hash13(i), hash13(i + vec3(1, 0, 0)), f.x),
                   mix(hash13(i + vec3(0, 1, 0)), hash13(i + vec3(1, 1, 0)), f.x), f.y),
               mix(mix(hash13(i + vec3(0, 0, 1)), hash13(i + vec3(1, 0, 1)), f.x),
                   mix(hash13(i + vec3(0, 1, 1)), hash13(i + vec3(1, 1, 1)), f.x), f.y), f.z);
}

float fbm(vec3 p, int oct) {
    float a = 0.5;
    float s = 0.0;
    for (int i = 0; i < oct; i++) {
        s += a * vnoise(p);
        p = p * 2.02 + vec3(17.1, 3.7, 9.2);
        a *= 0.5;
    }
    return s;
}

vec2 rot(vec2 v, float a) {
    float c = cos(a);
    float s = sin(a);
    return vec2(c * v.x - s * v.y, s * v.x + c * v.y);
}

vec3 tm(vec3 c) { return 1.0 - exp(-c * 1.2); }

float hgN(float c, float g) {
    float g2 = g * g;
    return (1.0 - g2) / pow(1.0 + g2 - 2.0 * g * c, 1.5);
}

uniform float Cover;
uniform float DayPhase;
const float CB = 190.0;
const float CT = 330.0;

// pw: x,z — мировые координаты (+ смещение ветра), y — абсолютная высота
float cumDensity(vec3 pw, int oct) {
    float hf = (pw.y - CB) / (CT - CB);
    if (hf < 0.0 || hf > 1.0) return 0.0;
    float cov = fbm(vec3(pw.x * 0.0005, DayPhase, pw.z * 0.0005), 3);
    float thr = mix(0.62, 0.40, Cover);
    float gate = ss(thr - 0.07, thr + 0.07, cov);
    if (gate <= 0.0) return 0.0;
    float core = ss(thr, thr + 0.12, cov);
    float hl = mix(0.5, 1.0, core);
    float shape = ss(0.0, 0.10, hf) * ss(hl, hl * 0.45, hf);   // плоское основание, округлая вершина
    float n = fbm(vec3(pw.x * 0.0045, pw.y * 0.0075, pw.z * 0.0045), oct);
    float d = gate * shape - (1.0 - n) * 0.62;
    return clamp(d * 2.2, 0.0, 1.0);
}

uniform float AnvilScale;
uniform float Realism;
uniform float SD[80];

struct StormInfo {
    vec2 c;
    float base;
    float top;
    float inten;
    float gr;
    vec2 dir;
    float tor;
    float gy;
    float R;
    float phase;
    vec2 tp;
    float rain;
    float shape;
    float meso;
};

StormInfo getStorm(int i) {
    int o = i * 20;
    StormInfo s;
    s.c = vec2(SD[o], SD[o + 1]);
    s.base = SD[o + 2];
    s.top = SD[o + 3];
    s.inten = SD[o + 4];
    s.gr = SD[o + 5];
    s.dir = vec2(SD[o + 6], SD[o + 7]);
    s.tor = SD[o + 8];
    s.gy = SD[o + 9];
    s.R = SD[o + 10];
    s.phase = SD[o + 11];
    s.tp = vec2(SD[o + 12], SD[o + 13]);
    s.rain = SD[o + 14];
    s.shape = SD[o + 15];
    s.meso = SD[o + 16];
    return s;
}

// Тело суперячейки как ЕДИНОЕ облако: апдрафт + широкое основание + толстая многослойная наковальня (мягкое объединение).
float cloudBody(vec3 p, StormInfo s, int oct, out float hOut) {
    hOut = 0.0;
    float R = s.R;
    float span = (s.top - s.base) * max(s.gr, 0.04);
    float h = (p.y - s.base) / span;
    hOut = clamp(h, 0.0, 1.0);
    if (h < -0.03 || h > 1.12 || s.gr < 0.02) return 0.0;

    vec2 q = p.xz - s.c;
    vec2 perp = vec2(-s.dir.y, s.dir.x);
    float hh = clamp(h, 0.0, 1.0);
    float grow = min(s.gr * 1.5, 1.0);

    // апдрафт: уже у основания, шире кверху, лёгкий наклон по ветру
    vec2 qt = q - s.dir * (hh * hh * R * 0.35);
    float rt = R * (0.55 + 0.40 * pow(hh, 0.7)) * (0.5 + 0.5 * grow);
    rt *= mix(1.0, 0.6, ss(0.93, 1.12, h));
    float mT = ss(1.0, 0.10, length(qt) / rt) * ss(-0.03, 0.06, h) * (1.0 - ss(0.96, 1.12, h));

    // широкое плоское основание (область притока), плавно переходит в башню
    float rb = R * (0.5 + 0.7 * grow) * 2.6;
    float mB = ss(1.0, 0.15, length(q - s.dir * R * 0.2) / rb) * ss(-0.03, 0.03, h) * (1.0 - ss(0.06, 0.20, h));

    // наковальня: огромная, толстая в центре, тонкая неровная периферия, свес и против ветра, слои
    float mA = 0.0;
    float ag = ss(0.45, 0.95, s.gr);
    if (ag > 0.01) {
        float a = max(R * (1.4 + 4.2 * AnvilScale) * ag, 1.0);
        vec2 qa = q - s.dir * (R * 0.35 + 0.30 * a);
        float u = dot(qa, s.dir) / a;
        float v = dot(qa, perp) / (a * 0.75);
        u *= (u < 0.0) ? 1.35 : 1.0;
        float e = length(vec2(u, v));
        float mm = vnoise(vec3(q * 0.03, 1.0));
        float hL = mix(0.84, 0.52, clamp(1.0 - e, 0.0, 1.0)) + (mm - 0.5) * 0.10;
        float hU = 0.99 - 0.06 * e;
        float lay = ss(hL, hL + 0.10, h) * (1.0 - ss(hU - 0.06, hU, h));
        lay *= 0.85 + 0.15 * sin(h * 38.0 + mm * 6.0);
        mA = ss(1.0, 0.05, e) * lay;
    }

    float mask = 1.0 - (1.0 - mT) * (1.0 - mB) * (1.0 - mA);
    if (mask < 0.002) return 0.0;
    float aw = mA / (mT + mB + mA + 1e-4);
    float bw = mB / (mT + mB + mA + 1e-4);

    vec2 qr = q;
    vec3 nc = vec3(qr.x, p.y * 1.5, qr.y) / (R * 0.4);
    nc += (vnoise(nc * 0.7 + vec3(3.0)) - 0.5) * 0.8;
    float n1 = fbm(nc, oct);
    float er = 0.30 + 0.28 * Realism;
    float d = mask - (1.0 - n1) * er * (1.0 - 0.45 * aw - 0.5 * bw);
    if (oct > 2) d -= (1.0 - fbm(nc * 3.7 + vec3(5.2, 1.3, 8.8), oct - 1)) * (0.06 + 0.20 * Realism) * (1.0 - 0.5 * mask) * (1.0 - 0.65 * aw);
    float ang = atan(qt.y, qt.x);
    float band = 0.5 + 0.5 * sin(ang * 5.0 - hh * 8.0 + s.phase * 1.5);
    d *= mix(1.0, 0.70 + 0.60 * band, ss(0.15, 0.6, hh) * (1.0 - aw) * 0.5);
    return clamp(d * 2.1, 0.0, 1.0);
}

// Тени облаков на земле (по буферу глубины) + подсветка земли вспышками молний.
void main() {
    float dsmp = texture(DepthSampler, ndc * 0.5 + 0.5).r;
    if (dsmp >= 0.99999) {
        fragColor = vec4(0.0);
        return;
    }
    vec4 wp = InvViewProj * vec4(ndc, dsmp * 2.0 - 1.0, 1.0);
    vec3 pr = wp.xyz / wp.w;
    float dist = length(pr);
    float fadeD = 1.0 - ss(1200.0, 1900.0, dist);
    vec3 pa = vec3(pr.x, CamPos.y + pr.y, pr.z);        // xz — от камеры, y — абсолютный
    float sunY = SunDir.y;
    float shade = 0.0;

    if (sunY >= 0.05 && ShadowStrength >= 0.01 && fadeD > 0.0) {
        float jit = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
        float tau = 0.0;
        if (AmbientCloud > 0.5) {
            vec3 pw0 = vec3(CamPos.x + pr.x + WindOffset.x, pa.y, CamPos.z + pr.z + WindOffset.y);
            float t0 = max((CB - pa.y) / sunY, 0.0);
            float t1 = (CT - pa.y) / sunY;
            if (t1 > t0) {
                float len = t1 - t0;
                for (int i = 0; i < 6; i++) {
                    float t = t0 + len * (float(i) + jit) / 6.0;
                    tau += cumDensity(pw0 + SunDir * t, 3) * len / 6.0 * 0.03;
                }
            }
        }
        int n = int(StormCount);
        for (int k = 0; k < 4; k++) {
            if (k >= n) break;
            StormInfo s = getStorm(k);
            float tEnd = min((s.top - pa.y) / sunY, 3500.0);
            if (tEnd <= 0.0) continue;
            vec2 endXZ = pa.xz + SunDir.xz * tEnd;
            vec2 mid = (pa.xz + endXZ) * 0.5 - s.c;
            float reach = s.R * (4.0 + 5.5 * AnvilScale) + tEnd * 0.5;
            if (length(mid) > reach) continue;
            for (int i = 0; i < 8; i++) {
                float t = tEnd * (float(i) + jit) / 8.0;
                float hh;
                tau += cloudBody(pa + SunDir * t, s, 2, hh) * (tEnd / 8.0) * 0.045;
            }
        }
        shade = (1.0 - exp(-tau)) * 0.62 * ShadowStrength * ss(0.05, 0.3, sunY) * fadeD;
    }

    float fa = FlashAmt * 0.30 * exp(-length(pa - FlashPos) / 450.0);
    float a = max(shade, fa);
    vec3 col = mix(vec3(0.01, 0.015, 0.035), vec3(0.62, 0.74, 1.0), fa / max(fa + shade, 1e-4));
    fragColor = vec4(col, a);
}
